import { useMemo, useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { MetricCard } from "./metric_card"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"

interface ServiceRow {
  service_id: number
  service_name: string
  contract_count: number
  total_revenue: number
  total_first_sum: number
}

interface SalesByServiceTableProps {
  data: ServiceRow[]
  /** Сколько строк показывать на странице (остальные попадут в "Прочие") */
  limit?: number
}

export function SalesByServiceTable({ data, limit = 10 }: SalesByServiceTableProps) {
  const [showAll, setShowAll] = useState(false)

  const getAvgFirstPayment = (row: ServiceRow) => {
    const value = row.total_first_sum ?? 0
    if (value > 0) return value
    return row.contract_count > 0 ? row.total_revenue / row.contract_count : 0
  }

  const aggregatedMetrics = useMemo(() => {
    const totalRevenue = data.reduce((acc, row) => acc + (row.total_revenue ?? 0), 0)
    const totalContracts = data.reduce((acc, row) => acc + (row.contract_count ?? 0), 0)
    const weightedFirstPayment = data.reduce(
      (acc, row) => acc + getAvgFirstPayment(row) * (row.contract_count ?? 0),
      0
    )
    const avgRevenuePerContract = totalContracts > 0 ? Math.round(totalRevenue / totalContracts) : 0
    const avgFirstPayment = totalContracts > 0 ? Math.round(weightedFirstPayment / totalContracts) : 0

    return { totalRevenue, totalContracts, avgRevenuePerContract, avgFirstPayment }
  }, [data])

  const { tableRows, othersRow, shownCount } = useMemo(() => {
    // Сортировка только для отображения (чтобы top-N были действительно топами)
    const sorted = [...data].sort(
      (a, b) => (b.total_revenue ?? 0) - (a.total_revenue ?? 0)
    )

    if (showAll || sorted.length <= limit) {
      return { tableRows: sorted, othersRow: null as ServiceRow | null, shownCount: sorted.length }
    }

    const top = sorted.slice(0, limit)
    const tail = sorted.slice(limit)

    const others: ServiceRow | null =
      tail.length > 0
        ? {
            service_id: -1,
            service_name: "Прочие",
            contract_count: tail.reduce((acc, r) => acc + (r.contract_count ?? 0), 0),
            total_revenue: tail.reduce((acc, r) => acc + (r.total_revenue ?? 0), 0),
            total_first_sum: (() => {
              const contracts = tail.reduce((acc, r) => acc + (r.contract_count ?? 0), 0)
              if (contracts <= 0) return 0
              const weighted = tail.reduce(
                (acc, r) => acc + getAvgFirstPayment(r) * (r.contract_count ?? 0),
                0
              )
              return weighted / contracts
            })(),
          }
        : null

    return { tableRows: top, othersRow: others, shownCount: top.length + (others ? 1 : 0) }
  }, [data, limit, showAll])

  const revenueShare = (value: number) =>
    aggregatedMetrics.totalRevenue > 0
      ? Number(((value / aggregatedMetrics.totalRevenue) * 100).toFixed(1))
      : 0

  return (
    <div className="space-y-4">
      {/* KPI карточки сверху (как было) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Середній перший платіж"
          value={`${aggregatedMetrics.avgFirstPayment.toLocaleString("uk-UA")} ₴`}
          subtitle="(оцінка, середнє по контрактах)"
        />
        <MetricCard
          title="Загальна виручка"
          value={`${aggregatedMetrics.totalRevenue.toLocaleString("uk-UA")} ₴`}
        />
        <MetricCard
          title="Усього контрактів"
          value={`${aggregatedMetrics.totalContracts.toLocaleString("uk-UA")}`}
        />
        <MetricCard
          title="Середній чек"
          value={`${aggregatedMetrics.avgRevenuePerContract.toLocaleString("uk-UA")} ₴`}
        />
      </div>

      {/* Таблица */}
      <div className="rounded-lg border overflow-hidden">
        <div className="max-h-[520px] overflow-auto">
          <Table className="text-sm">
            <TableHeader className="sticky top-0 bg-white/90 backdrop-blur supports-[backdrop-filter]:bg-white/60 z-10">
              <TableRow>
                <TableHead className="w-[40%]">Послуга</TableHead>
                <TableHead className="text-right">Контракти</TableHead>
                <TableHead className="text-right">Виручка</TableHead>
                <TableHead className="text-right">Сер. перший платіж</TableHead>
                <TableHead className="text-right">Доля</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tableRows.length > 0 ? (
                tableRows.map((row) => {
                  const share = revenueShare(row.total_revenue)
                  const avgFirstPayment = getAvgFirstPayment(row)
                  return (
                    <TableRow
                      key={row.service_id}
                      className="hover:bg-muted/40 transition-colors even:bg-muted/20"
                    >
                      <TableCell className="pr-4">
                        <div className="flex items-center gap-2">
                          <span className="truncate">{row.service_name}</span>
                        </div>
                      </TableCell>

                      <TableCell className="text-right tabular-nums">
                        {row.contract_count.toLocaleString("uk-UA")}
                      </TableCell>

                      <TableCell className="text-right tabular-nums">
                        {row.total_revenue?.toLocaleString("uk-UA")} ₴
                      </TableCell>

                      <TableCell className="text-right tabular-nums">
                        {avgFirstPayment.toLocaleString("uk-UA")} ₴
                      </TableCell>

                      <TableCell className="text-right">
                        <div className="inline-flex flex-col items-end gap-1">
                          <span className="tabular-nums">{share}%</span>
                          <div className="w-28 h-1.5 bg-muted rounded-full overflow-hidden">
                            <div
                              className={cn("h-full bg-blue-600")}
                              style={{ width: `${Math.min(share, 100)}%` }}
                            />
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground italic py-8">
                    Немає даних за послугами за вибраний період.
                  </TableCell>
                </TableRow>
              )}

              {/* Строка «Прочие» при сокращённом отображении */}
              {!showAll && othersRow && (
                <TableRow className="bg-muted/30">
                  <TableCell className="font-medium">Прочие</TableCell>
                  <TableCell className="text-right tabular-nums">
                    {othersRow.contract_count.toLocaleString("uk-UA")}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {othersRow.total_revenue.toLocaleString("uk-UA")} ₴
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {othersRow.total_first_sum.toLocaleString("uk-UA")} ₴
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex flex-col items-end gap-1">
                      <span className="tabular-nums">
                        {revenueShare(othersRow.total_revenue)}%
                      </span>
                      <div className="w-28 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600"
                          style={{ width: `${Math.min(revenueShare(othersRow.total_revenue), 100)}%` }}
                        />
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              )}

              {/* Итого */}
              {tableRows.length > 0 && (
                <TableRow className="font-medium border-t">
                  <TableCell>Всього</TableCell>
                  <TableCell className="text-right tabular-nums">
                    {aggregatedMetrics.totalContracts.toLocaleString("uk-UA")}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {aggregatedMetrics.totalRevenue.toLocaleString("uk-UA")} ₴
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {aggregatedMetrics.avgFirstPayment.toLocaleString("uk-UA")} ₴
                  </TableCell>
                  <TableCell className="text-right tabular-nums">100%</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Панель управления под таблицей */}
        <div className="flex items-center justify-between px-3 py-2 bg-muted/30">
          <div className="text-xs text-muted-foreground">
            Показано:{" "}
            <span className="font-medium">{shownCount}</span> із{" "}
            <span className="font-medium">{data.length}</span> послуг
          </div>
          {data.length > limit && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAll((v) => !v)}
              className="gap-2"
            >
              {showAll ? (
                <>
                  Згорнути <ChevronUp className="h-4 w-4" />
                </>
              ) : (
                <>
                  Показати всі <ChevronDown className="h-4 w-4" />
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
