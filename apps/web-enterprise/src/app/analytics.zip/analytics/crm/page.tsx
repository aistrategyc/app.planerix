export const dynamic = "force-dynamic"

import CRMPageClient from "./CRMPageClient"

export default function CRMPage() {
  return <CRMPageClient />
}
