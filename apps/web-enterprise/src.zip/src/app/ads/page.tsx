import AdsAnalyticsPage from "@/app/analytics/ads/page"

export default function AdsPage() {
  return <AdsAnalyticsPage />
}
