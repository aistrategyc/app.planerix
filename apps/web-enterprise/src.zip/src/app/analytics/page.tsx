"use client"

import CRMPageClient from "@/app/analytics/crm/CRMPageClient"

export default function AnalyticsPage() {
  return <CRMPageClient />
}
