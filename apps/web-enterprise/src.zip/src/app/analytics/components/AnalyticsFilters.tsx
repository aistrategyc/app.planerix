"use client"

import { DateRangePicker } from "@/components/ui/date_range_picker"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useCities } from "@/app/analytics/hooks/use_cities"
import { SlidersHorizontal } from "lucide-react"

export type AnalyticsFiltersValue = {
  dateRange: { from?: Date; to?: Date }
  cityId: string
  platform: string
  product?: string
  branch?: string
  source?: string
}

type AnalyticsFiltersProps = {
  value: AnalyticsFiltersValue
  onDateChange: (value: { from?: Date; to?: Date }) => void
  onCityChange: (value: string) => void
  onPlatformChange: (value: string) => void
  onProductChange?: (value: string) => void
  onBranchChange?: (value: string) => void
  onSourceChange?: (value: string) => void
  onApply: () => void
  onReset: () => void
  isLoading?: boolean
  showDateRange?: boolean
  showCity?: boolean
  showPlatform?: boolean
  showProduct?: boolean
  showBranch?: boolean
  showSource?: boolean
}

export function AnalyticsFilters({
  value,
  onDateChange,
  onCityChange,
  onPlatformChange,
  onProductChange,
  onBranchChange,
  onSourceChange,
  onApply,
  onReset,
  isLoading,
  showDateRange = true,
  showCity = true,
  showPlatform = true,
  showProduct = false,
  showBranch = false,
  showSource = false,
}: AnalyticsFiltersProps) {
  const { cities } = useCities()
  const safeProduct = value.product ?? ""
  const safeBranch = value.branch ?? ""
  const safeSource = value.source ?? ""
  const handleProduct = onProductChange ?? (() => {})
  const handleBranch = onBranchChange ?? (() => {})
  const handleSource = onSourceChange ?? (() => {})

  return (
    <Card className="border-muted/70 shadow-sm">
      <CardContent className="flex flex-wrap items-center gap-2 py-2">
        <div className="hidden items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground md:flex">
          <SlidersHorizontal className="h-3 w-3" />
          Фільтри
        </div>
        {showDateRange && (
          <DateRangePicker value={value.dateRange} onChange={onDateChange} className="h-7 w-[160px]" />
        )}
        {showCity && (
          <Select value={value.cityId} onValueChange={onCityChange}>
            <SelectTrigger className="h-7 w-[140px]">
              <SelectValue placeholder="Місто" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Усі міста</SelectItem>
              {cities.map((city) => (
                <SelectItem key={city.id_city} value={String(city.id_city)}>
                  {city.city_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        {showPlatform && (
          <Select value={value.platform} onValueChange={onPlatformChange}>
            <SelectTrigger className="h-7 w-[130px]">
              <SelectValue placeholder="Платформа" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Усі платформи</SelectItem>
              <SelectItem value="meta">Meta</SelectItem>
              <SelectItem value="gads">Google Ads</SelectItem>
              <SelectItem value="offline">Offline</SelectItem>
            </SelectContent>
          </Select>
        )}
        {showProduct && (
          <Input
            value={safeProduct}
            onChange={(event) => handleProduct(event.target.value)}
            placeholder="Продукт"
            className="h-7 w-[150px]"
          />
        )}
        {showBranch && (
          <Input
            value={safeBranch}
            onChange={(event) => handleBranch(event.target.value)}
            placeholder="Філія"
            className="h-7 w-[130px]"
          />
        )}
        {showSource && (
          <Input
            value={safeSource}
            onChange={(event) => handleSource(event.target.value)}
            placeholder="Джерело"
            className="h-7 w-[150px]"
          />
        )}
        <Button variant="secondary" size="sm" className="h-7 px-3" onClick={onApply} disabled={isLoading}>
          Застосувати
        </Button>
        <Button variant="ghost" size="sm" className="h-7 px-3" onClick={onReset} disabled={isLoading}>
          Скинути
        </Button>
      </CardContent>
    </Card>
  )
}
