import ContractsAnalyticsPageView from "@/app/analytics/contracts/page"

export default function ContractsAnalyticsPage() {
  return <ContractsAnalyticsPageView />
}
