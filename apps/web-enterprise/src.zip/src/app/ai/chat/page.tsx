"use client"

import ProtectedRoute from "@/components/auth/ProtectedRoute"
import AIChat from "@/components/ai/AIChat"

export default function AIChatPage() {
  return (
    <ProtectedRoute requireAuth={true}>
      <div className="flex flex-col max-w-4xl mx-auto p-6 min-h-[calc(100vh-80px)]">
        <h1 className="text-2xl font-bold mb-4">💬 AI-чат с аналитическим агентом</h1>
        <AIChat />
      </div>
    </ProtectedRoute>
  )
}
