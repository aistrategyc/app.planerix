import CampaignsSourcesPage from "@/app/analytics/campaigns-sources/page"

export default function MarketingPage() {
  return <CampaignsSourcesPage />
}
