import AttributionOverviewClient from "@/app/attribution/overview/AttributionOverviewClient"

export const dynamic = "force-dynamic"

export default function AttributionOverviewPage() {
  return <AttributionOverviewClient />
}
