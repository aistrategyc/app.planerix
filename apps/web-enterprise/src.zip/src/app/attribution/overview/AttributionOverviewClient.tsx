"use client"

import { useEffect, useMemo, useState } from "react"
import { useSearchParams } from "next/navigation"
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import { AttributionFilterBar } from "@/app/attribution/components/AttributionFilterBar"
import { useAttributionFilters } from "@/app/attribution/hooks/useAttributionFilters"
import type { AttributionFiltersValue } from "@/app/attribution/types"
import { buildDateKey } from "@/app/attribution/utils/filters"
import { buildLastWeekRange, resolveDefaultCityId } from "@/app/analytics/utils/defaults"
import { formatCurrency, formatNumber } from "@/app/analytics/utils/formatters"
import { useCities } from "@/app/analytics/hooks/use_cities"
import { KpiSparkline } from "@/app/analytics/components/KpiSparkline"
import { WidgetStatus } from "@/app/analytics/components/WidgetStatus"
import { fetchAttributionWidgets } from "@/lib/api/attribution"
import { fetchWidgetRange } from "@/lib/api/analytics-widgets"
import { useAuth } from "@/contexts/auth-context"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

const OVERVIEW_WIDGET_KEYS = [
  "attr.overview.kpi_total",
  "attr.overview.ts_core",
  "attr.overview.channel_mix",
]

type AttributionKpiRow = {
  impressions?: number | null
  clicks?: number | null
  spend?: number | null
  conversions?: number | null
  conversion_value?: number | null
  platform_leads?: number | null
  crm_requests_cnt?: number | null
}

type AttributionTrendRow = {
  date_key?: string | null
  spend?: number | null
  clicks?: number | null
  impressions?: number | null
  platform_leads?: number | null
  crm_requests_cnt?: number | null
}

type ChannelMixRow = {
  date_key?: string | null
  channel?: string | null
  platform?: string | null
  spend?: number | null
  leads_cnt?: number | null
  contracts_cnt?: number | null
}

type AttributionWidgetsPayload = {
  widgets: Record<string, { data: { current: any[]; compare?: any[] }; meta: { missing_view?: boolean } }>
}

const toNumber = (value: unknown) => {
  if (typeof value === "number") return value
  if (typeof value === "string") {
    const parsed = Number(value)
    return Number.isNaN(parsed) ? null : parsed
  }
  return null
}

const buildSparkline = (rows: AttributionTrendRow[], key: keyof AttributionTrendRow) =>
  rows.map((row) => ({ value: toNumber(row[key]) }))

export default function AttributionOverviewClient() {
  const searchParams = useSearchParams()
  const { cities } = useCities()
  const { isAuthenticated, isLoading: authLoading } = useAuth()
  const canFetch = isAuthenticated && !authLoading

  const {
    draftFilters,
    appliedFilters,
    setDraftFilters,
    setAppliedFilters,
    applyFilters,
    resetFilters,
    updateQuery,
  } = useAttributionFilters()

  const [defaultsApplied, setDefaultsApplied] = useState(false)
  const [data, setData] = useState<AttributionWidgetsPayload>({ widgets: {} })
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (!canFetch) return
    if (defaultsApplied) return
    if (searchParams.get("date_from") || searchParams.get("date_to")) {
      setDefaultsApplied(true)
      return
    }
    let active = true
    const hydrateDefaults = async () => {
      try {
        const range = await fetchWidgetRange("ads.kpi_total")
        if (!active) return
        const dateRange = buildLastWeekRange(range.max_date)
        if (!dateRange) {
          setDefaultsApplied(true)
          return
        }
        const nextFilters: AttributionFiltersValue = {
          ...draftFilters,
          dateRange,
        }
        setDraftFilters(nextFilters)
        setAppliedFilters(nextFilters)
        updateQuery({
          date_from: buildDateKey(dateRange.from),
          date_to: buildDateKey(dateRange.to),
        })
      } finally {
        if (active) setDefaultsApplied(true)
      }
    }
    hydrateDefaults()
    return () => {
      active = false
    }
  }, [canFetch, defaultsApplied, draftFilters, searchParams, setAppliedFilters, setDraftFilters, updateQuery])

  useEffect(() => {
    if (searchParams.get("id_city")) return
    const cityId = resolveDefaultCityId(cities)
    if (!cityId) return
    setDraftFilters((prev) => ({ ...prev, cityId: String(cityId) }))
    setAppliedFilters((prev) => ({ ...prev, cityId: String(cityId) }))
    updateQuery({ id_city: String(cityId) })
  }, [cities, searchParams, setAppliedFilters, setDraftFilters, updateQuery])

  const requestParams = useMemo(() => {
    const params: Record<string, string | number | undefined> = {}
    if (appliedFilters.dateRange.from) {
      params.date_from = buildDateKey(appliedFilters.dateRange.from)
    }
    if (appliedFilters.dateRange.to) {
      params.date_to = buildDateKey(appliedFilters.dateRange.to)
    }
    if (appliedFilters.compareMode !== "none") {
      params.compare = appliedFilters.compareMode
    }
    if (appliedFilters.compareMode === "custom") {
      if (appliedFilters.compareRange.from) {
        params.compare_from = buildDateKey(appliedFilters.compareRange.from)
      }
      if (appliedFilters.compareRange.to) {
        params.compare_to = buildDateKey(appliedFilters.compareRange.to)
      }
    }
    if (appliedFilters.cityId !== "all") {
      params.id_city = appliedFilters.cityId
    }
    if (appliedFilters.platform !== "all") {
      params.platform = appliedFilters.platform
    }
    if (appliedFilters.channel !== "all") {
      params.channel = appliedFilters.channel
    }
    if (appliedFilters.device !== "all") {
      params.device = appliedFilters.device
    }
    if (appliedFilters.conversionType !== "all") {
      params.conversion_type = appliedFilters.conversionType
    }
    return params
  }, [appliedFilters])

  useEffect(() => {
    let active = true
    const load = async () => {
      if (!canFetch) return
      setIsLoading(true)
      try {
        const response = await fetchAttributionWidgets({
          widgetKeys: OVERVIEW_WIDGET_KEYS,
          filters: requestParams,
        })
        if (!active) return
        setData(response)
      } catch (error) {
        if (!active) return
        console.error("Failed to load attribution overview widgets", error)
        setData({ widgets: {} })
      } finally {
        if (active) setIsLoading(false)
      }
    }
    load()
    return () => {
      active = false
    }
  }, [canFetch, requestParams])

  const kpiWidget = data.widgets["attr.overview.kpi_total"] as
    | { data: { current: AttributionKpiRow[] }; meta: { missing_view?: boolean } }
    | undefined
  const trendWidget = data.widgets["attr.overview.ts_core"] as
    | { data: { current: AttributionTrendRow[] }; meta: { missing_view?: boolean } }
    | undefined
  const channelWidget = data.widgets["attr.overview.channel_mix"] as
    | { data: { current: ChannelMixRow[] }; meta: { missing_view?: boolean } }
    | undefined

  const kpiRow = kpiWidget?.data?.current?.[0]
  const trendRows = trendWidget?.meta?.missing_view ? [] : trendWidget?.data?.current ?? []
  const channelRows = channelWidget?.data?.current ?? []

  const spendSparkline = buildSparkline(trendRows, "spend")
  const clickSparkline = buildSparkline(trendRows, "clicks")
  const impressionSparkline = buildSparkline(trendRows, "impressions")
  const platformLeadsSparkline = buildSparkline(trendRows, "platform_leads")
  const crmLeadsSparkline = buildSparkline(trendRows, "crm_requests_cnt")

  const trendChartData = trendRows.map((row) => ({
    date: row.date_key ?? "",
    spend: toNumber(row.spend) ?? 0,
    platform_leads: toNumber(row.platform_leads) ?? 0,
    crm_requests_cnt: toNumber(row.crm_requests_cnt) ?? 0,
  }))

  const topChannels = [...channelRows]
    .sort((a, b) => (toNumber(b.spend) ?? 0) - (toNumber(a.spend) ?? 0))
    .slice(0, 6)

  const renderMetric = (label: string, value: string, sparkline: { value: number | null }[], tone = "#3b82f6") => (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm text-muted-foreground">{label}</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-between gap-3">
        <div className="text-2xl font-semibold">{value}</div>
        <div className="w-24 shrink-0">
          <KpiSparkline data={sparkline} stroke={tone} />
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      <AttributionFilterBar
        value={draftFilters}
        onChange={(next) => setDraftFilters((prev) => ({ ...prev, ...next }))}
        onApply={applyFilters}
        onReset={resetFilters}
        isLoading={isLoading}
      />

      {kpiWidget?.meta?.missing_view && (
        <WidgetStatus
          title="Витрина KPI не найдена"
          description="Нужно зарегистрировать attr.overview.kpi_total в core и создать view в SEM."
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4">
        {isLoading ? (
          [...Array(5)].map((_, index) => <Skeleton key={index} className="h-[104px]" />)
        ) : (
          <>
            {renderMetric("Spend", formatCurrency(kpiRow?.spend), spendSparkline)}
            {renderMetric("Clicks", formatNumber(kpiRow?.clicks), clickSparkline, "#0ea5e9")}
            {renderMetric("Impressions", formatNumber(kpiRow?.impressions), impressionSparkline, "#38bdf8")}
            {renderMetric("Platform Leads", formatNumber(kpiRow?.platform_leads), platformLeadsSparkline, "#10b981")}
            {renderMetric("CRM Leads", formatNumber(kpiRow?.crm_requests_cnt), crmLeadsSparkline, "#f97316")}
          </>
        )}
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Performance over time</CardTitle>
        </CardHeader>
        <CardContent>
          {trendWidget?.meta?.missing_view ? (
            <WidgetStatus
              title="Витрина трендов не найдена"
              description="Нужно зарегистрировать attr.overview.ts_core и создать view для временных рядов."
            />
          ) : (
            <div className="h-[280px]">
              <ResponsiveContainer>
                <ComposedChart data={trendChartData} margin={{ left: 8, right: 8, top: 8, bottom: 0 }}>
                  <defs>
                    <linearGradient id="attrSpendFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#93c5fd" stopOpacity={0.45} />
                      <stop offset="95%" stopColor="#93c5fd" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="#e2e8f0" strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis yAxisId="spend" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis
                    yAxisId="leads"
                    orientation="right"
                    tick={{ fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    formatter={(value: number, name: string) => {
                      if (name === "spend") return [formatCurrency(value), "Spend"]
                      if (name === "platform_leads") return [formatNumber(value), "Platform leads"]
                      if (name === "crm_requests_cnt") return [formatNumber(value), "CRM leads"]
                      return [formatNumber(value), name]
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="spend"
                    yAxisId="spend"
                    stroke="#3b82f6"
                    fill="url(#attrSpendFill)"
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="platform_leads"
                    yAxisId="leads"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="crm_requests_cnt"
                    yAxisId="leads"
                    stroke="#f97316"
                    strokeWidth={2}
                    dot={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Channel mix</CardTitle>
          </CardHeader>
          <CardContent>
            {channelWidget?.meta?.missing_view ? (
              <WidgetStatus
                title="Нет витрины channel mix"
                description="Нужно зарегистрировать attr.overview.channel_mix и подготовить view."
              />
            ) : (
              <div className="space-y-2">
                {topChannels.length === 0 && !isLoading && (
                  <div className="text-sm text-muted-foreground">Нет данных для выбранного периода.</div>
                )}
                {topChannels.map((row, index) => {
                  const label = row.channel ?? row.platform ?? `Channel ${index + 1}`
                  return (
                    <div key={`${label}-${index}`} className="flex items-center justify-between text-sm">
                      <span className="font-medium">{label}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-[11px]">
                          Spend {formatCurrency(row.spend)}
                        </Badge>
                        <Badge variant="outline" className="text-[11px]">
                          Leads {formatNumber(row.leads_cnt)}
                        </Badge>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>City breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <WidgetStatus
              title="Витрина городов в очереди"
              description="Добавим attr.overview.city_breakdown на следующем этапе." 
            />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
