import AttributionRevenueClient from "@/app/attribution/revenue/AttributionRevenueClient"

export const dynamic = "force-dynamic"

export default function AttributionRevenuePage() {
  return <AttributionRevenueClient />
}
