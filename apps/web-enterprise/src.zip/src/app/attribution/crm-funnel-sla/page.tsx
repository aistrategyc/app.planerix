import AttributionCrmFunnelSlaClient from "@/app/attribution/crm-funnel-sla/AttributionCrmFunnelSlaClient"

export const dynamic = "force-dynamic"

export default function AttributionCrmFunnelPage() {
  return <AttributionCrmFunnelSlaClient />
}
