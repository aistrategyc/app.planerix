import AttributionInteractionsClient from "@/app/attribution/interactions/AttributionInteractionsClient"

export const dynamic = "force-dynamic"

export default function AttributionInteractionsPage() {
  return <AttributionInteractionsClient />
}
