import AttributionAdsCampaignsClient from "@/app/attribution/ads/campaigns/AttributionAdsCampaignsClient"

export const dynamic = "force-dynamic"

export default function AttributionAdsPage() {
  return <AttributionAdsCampaignsClient />
}
