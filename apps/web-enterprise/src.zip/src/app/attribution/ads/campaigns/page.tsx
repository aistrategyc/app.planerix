import AttributionAdsCampaignsClient from "@/app/attribution/ads/campaigns/AttributionAdsCampaignsClient"

export const dynamic = "force-dynamic"

export default function AttributionAdsCampaignsPage() {
  return <AttributionAdsCampaignsClient />
}
