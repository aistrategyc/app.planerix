"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Activity,
  BarChart3,
  Layers,
  LineChart,
  PieChart,
  Target,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface AttributionLayoutProps {
  children: React.ReactNode
}

const NAV_ITEMS = [
  {
    name: "Overview",
    href: "/attribution/overview",
    icon: PieChart,
    description: "KPI, тренды и микс каналов",
  },
  {
    name: "Content",
    href: "/attribution/content",
    icon: Layers,
    description: "Контент и посадочные страницы",
  },
  {
    name: "Interactions",
    href: "/attribution/interactions",
    icon: LineChart,
    description: "События и вовлеченность",
  },
  {
    name: "Ads",
    href: "/attribution/ads",
    icon: BarChart3,
    description: "Кампании и креативы",
  },
  {
    name: "Revenue",
    href: "/attribution/revenue",
    icon: Target,
    description: "Атрибуция и выручка",
  },
  {
    name: "CRM Funnel & SLA",
    href: "/attribution/crm-funnel-sla",
    icon: Activity,
    description: "Качество лидов и SLA",
  },
]

export default function AttributionLayout({ children }: AttributionLayoutProps) {
  const pathname = usePathname()

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Attribution</h1>
              <p className="mt-1 text-sm text-slate-500">
                Единый модуль для связки рекламных расходов и результата бизнеса
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {NAV_ITEMS.map((item) => {
            const isActive = pathname === item.href
            const Icon = item.icon

            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "group relative rounded-lg p-4 transition-all hover:shadow-lg",
                  isActive
                    ? "bg-blue-50 border-2 border-blue-200 shadow-md"
                    : "bg-white border border-slate-200 hover:border-slate-300"
                )}
              >
                <div className="flex items-center space-x-3">
                  <Icon
                    className={cn(
                      "h-6 w-6 transition-colors",
                      isActive ? "text-blue-600" : "text-slate-400 group-hover:text-slate-500"
                    )}
                  />
                  <div className="flex-1 min-w-0">
                    <p
                      className={cn(
                        "text-sm font-medium truncate",
                        isActive ? "text-blue-900" : "text-slate-900"
                      )}
                    >
                      {item.name}
                    </p>
                    <p className={cn("text-xs truncate", isActive ? "text-blue-600" : "text-slate-500")}>
                      {item.description}
                    </p>
                  </div>
                </div>

                {isActive && <div className="absolute inset-x-0 -bottom-px h-1 bg-blue-600 rounded-b-lg" />}
              </Link>
            )
          })}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">{children}</div>
    </div>
  )
}
