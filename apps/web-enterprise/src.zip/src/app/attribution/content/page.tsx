import AttributionContentClient from "@/app/attribution/content/AttributionContentClient"

export const dynamic = "force-dynamic"

export default function AttributionContentPage() {
  return <AttributionContentClient />
}
