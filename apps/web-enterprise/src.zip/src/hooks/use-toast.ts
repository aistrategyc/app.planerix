// Re-export from components/ui/use-toast for compatibility
export * from '@/components/ui/use-toast'
export { useToast as default } from '@/components/ui/use-toast'