import { api } from './config'

export type ObjectiveStatus = 'draft' | 'active' | 'completed' | 'archived'

export interface KeyResult {
  id: string
  objective_id: string
  description: string
  start_value: number
  target_value: number
  current_value: number
  unit?: string | null
  progress_percentage?: number
  created_at?: string
  updated_at?: string | null
  deleted_at?: string | null
}

export interface OKR {
  id: string
  org_id: string
  title: string
  description?: string
  status: ObjectiveStatus
  start_date?: string | null
  due_date?: string | null
  key_results: KeyResult[]
  created_at: string
  updated_at?: string | null
  deleted_at?: string | null
  overall_progress?: number
  completed_key_results?: number
  is_overdue?: boolean
}

export interface KeyResultCreate {
  description: string
  start_value?: number
  target_value: number
  current_value?: number
  unit?: string
}

export interface KeyResultUpdate {
  description?: string
  start_value?: number
  target_value?: number
  current_value?: number
  unit?: string
}

export interface OKRCreate {
  title: string
  description?: string
  status?: ObjectiveStatus
  start_date?: string
  due_date?: string
  key_results?: KeyResultCreate[]
}

export interface OKRUpdate {
  title?: string
  description?: string
  status?: ObjectiveStatus
  start_date?: string
  due_date?: string
}

interface ObjectiveListResponse {
  items: OKR[]
  total: number
  page: number
  page_size: number
}

export class OKRsAPI {
  static async list(params?: { page?: number; page_size?: number; status?: ObjectiveStatus; search?: string }): Promise<OKR[]> {
    const response = await api.get<ObjectiveListResponse>('/okrs/objectives', { params })
    return response.data.items || []
  }

  static async get(id: string): Promise<OKR> {
    const response = await api.get<OKR>(`/okrs/objectives/${id}`)
    return response.data
  }

  static async create(data: OKRCreate): Promise<OKR> {
    const response = await api.post<OKR>('/okrs/objectives', data)
    return response.data
  }

  static async update(id: string, data: OKRUpdate): Promise<OKR> {
    const response = await api.put<OKR>(`/okrs/objectives/${id}`, data)
    return response.data
  }

  static async delete(id: string): Promise<void> {
    await api.delete(`/okrs/objectives/${id}`)
  }

  static async listKeyResults(objectiveId: string): Promise<KeyResult[]> {
    const response = await api.get<KeyResult[]>(`/okrs/objectives/${objectiveId}/key-results`)
    return response.data || []
  }

  static async createKeyResult(objectiveId: string, data: KeyResultCreate): Promise<KeyResult> {
    const response = await api.post<KeyResult>(`/okrs/objectives/${objectiveId}/key-results`, data)
    return response.data
  }

  static async updateKeyResult(keyResultId: string, data: KeyResultUpdate): Promise<KeyResult> {
    const response = await api.put<KeyResult>(`/okrs/key-results/${keyResultId}`, data)
    return response.data
  }

  static async deleteKeyResult(keyResultId: string): Promise<void> {
    await api.delete(`/okrs/key-results/${keyResultId}`)
  }
}
