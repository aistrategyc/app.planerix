"use client"

import { usePathname } from 'next/navigation'
import Header from '@/components/ui/header'
import Sidebar from '@/components/ui/sidebar'

interface AppLayoutProps {
  children: React.ReactNode
}

export function AppLayout({ children }: AppLayoutProps) {
  const pathname = usePathname()

  // Pages that should not show the header/sidebar (none - show header on all pages)
  const authPages: string[] = []
  const isAuthPage = authPages.includes(pathname)

  if (isAuthPage) {
    return <>{children}</>
  }

  return (
    <>
      <Header />
      <div className="relative flex min-h-screen">
        <Sidebar />
        <main className="flex-1 overflow-y-auto bg-slate-50/80 backdrop-blur-sm pt-[72px] pb-6 pr-4 pl-[64px] md:pb-8 md:pr-6 md:pl-[80px]">
          <div className="mx-auto w-full max-w-[1400px]">
            {children}
          </div>
        </main>
      </div>
    </>
  )
}
